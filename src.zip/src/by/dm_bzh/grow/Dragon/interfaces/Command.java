package by.dm_bzh.grow.Dragon.interfaces;

public interface Command {
    public String execute();    
}
